import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employees$!: Observable<any>;
  constructor(private http : HttpClient) { }

  ngOnInit(): void {
     this.employees$ = this.http.get('http://localhost:8090/api/v1/employees');
     
  }

}
