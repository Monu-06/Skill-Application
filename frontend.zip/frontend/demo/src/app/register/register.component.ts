import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit{
  frmRegister: FormGroup;
  constructor(private http: HttpClient){
    this.frmRegister = this.addNewEmployee();
  }
  ngOnInit(): void {}
  addNewEmployee() {
  return new FormGroup({
    empId: new FormControl('',[Validators.required]),
    empname: new FormControl('', [Validators.required]),
    skill: new FormControl('', [Validators.required]),
    rating: new FormControl('', [Validators.required]),
    experience: new FormControl('', [Validators.required]),
    certification: new FormControl('', [Validators.required]),
    kpi: new FormControl('', [Validators.required])
  });
}
onSubmit(): void{
 console.log(this.frmRegister.value);
   this.http.post('http://localhost:8090/api/v1/employees',this.frmRegister.value).subscribe(response => console.log(response));
   alert("Employee details are added!");
};
}
