import { HttpClient } from '@angular/common/http';
import { Component,OnInit } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  empId:String='';
  empname:String='';
  skill:String='';
  rating:String='';
  experience:String='';
  certification:String='';
  kpi:String='';
  temp:any;

  constructor(private http:HttpClient){}

  ngOnInit(): void {
    this.http.get('http://localhost:8090/api/v1/employees').subscribe((data)=>{
      this.temp=data;
    });
  }
  
searchByEmpName(){
    if(this.empname!=""){
      this.temp=this.temp.filter((res:any)=>{
        return res.empname.toLocaleLowerCase().match(this.empname.toLocaleLowerCase());
     })
    }
     else if(this.empname=""){
      this.temp=this.temp.filter((res:any)=>{
        return res.empname.toLocaleLowerCase().match(this.empname.toLocaleLowerCase());
    });
    
  }
  else{
    this.ngOnInit();
  }
  }
  
  searchBySkill(){
    if(this.skill!=""){
      this.temp=this.temp.filter((res:any)=>{
        return res.skill.toLocaleLowerCase().match(this.skill.toLocaleLowerCase());
     })
    }
     else if(this.skill=""){
      this.temp=this.temp.filter((res:any)=>{
        return res.skill.toLocaleLowerCase().match(this.skill.toLocaleLowerCase());
      })
    }
    else{
      this.ngOnInit();
    }
  }
  searchByRating(){
    if(this.rating!=""){
      this.temp=this.temp.filter((res:any)=>{
        return res.rating.match(this.rating);
     })
    }
     else if(this.rating=""){
      this.temp=this.temp.filter((res:any)=>{
        return res.rating.match(this.rating);
     })
    }
    else{
      this.ngOnInit();
    }
  }
  searchByExperience(){
    if(this.experience!=""){
      this.temp=this.temp.filter((res:any)=>{
        return res.experience.match(this.experience);
     })
    }
     else if(this.experience=""){
      this.temp=this.temp.filter((res:any)=>{
        return res.experience.match(this.experience);
     })
    }
    else{
      this.ngOnInit();
    }
  }
  searchByCertification(){
    if(this.certification!=""){
      this.temp=this.temp.filter((res:any)=>{
        return res.certification.toLocaleLowerCase().match(this.certification.toLocaleLowerCase());
     })
    }
     else if(this.certification=""){
      this.temp=this.temp.filter((res:any)=>{
        return res.certification.toLocaleLowerCase().match(this.certification.toLocaleLowerCase());
     })
    }
    else{
      this.ngOnInit();
    }
  }
  searchByKpi(){
    if(this.kpi!=""){
      this.temp=this.temp.filter((res:any)=>{
        return res.kpi.toLocaleLowerCase().match(this.kpi.toLocaleLowerCase());
     })
    }
     else if(this.kpi=""){
      this.temp=this.temp.filter((res:any)=>{
        return res.kpi.toLocaleLowerCase().match(this.kpi.toLocaleLowerCase());
    });
  }
  else{
    this.ngOnInit();
  }
  }
}
