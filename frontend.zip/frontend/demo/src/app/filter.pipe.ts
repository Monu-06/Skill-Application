import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
  transform(items: any[], searchText: string): any[] {
    if(!items) return [];
    if(!searchText) return items;
searchText = searchText.toLowerCase();
return items.filter( it => {
      return it.empname.toLowerCase().includes(searchText) || it.skill.toLowerCase().includes(searchText) || it.rating.includes(searchText)|| it.experience.includes(searchText) || it.certification.toLowerCase().includes(searchText);
    });
   }

}
