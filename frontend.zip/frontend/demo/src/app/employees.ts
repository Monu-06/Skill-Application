export class Employee{
      "empId": String;
      "empname":String;
      "skill": String;
      "rating": String;
      "experience": String;
      "certification": String;
      "kpi":String;
}