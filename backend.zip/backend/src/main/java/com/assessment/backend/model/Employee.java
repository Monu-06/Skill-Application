package com.assessment.backend.model;

import javax.persistence.*;

@Entity
@Table(name="skills")
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name="emp_Id",nullable = false)
    private long empId;
    @Column(name="emp_name",nullable = false)
    private String empname;
    @Column(name="skill",nullable = false)
    private String skill;
    @Column(name="rating",nullable = false)
    private String rating;
    @Column(name="experience",nullable = false)
    private String experience;
    @Column(name="certification",nullable = false)
    private String certification;
    @Column(name="kpi",nullable = false)
    private String kpi;



    public Employee() {
    }
    //constructor used to intiliaze the objects

    public Employee(long empId, String empname, String skill, String rating, String experience, String certification,String kpi) {
        this.empId = empId;
        this.empname = empname;
        this.skill = skill;
        this.rating = rating;
        this.experience = experience;
        this.certification = certification;
        this.kpi=kpi;
    }

    //getters & setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getEmpId() {
        return empId;
    }

    public void setEmpId(long empId) {
        this.empId = empId;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getCertification() {
        return certification;
    }

    public void setCertification(String certification) {
        this.certification = certification;
    }

    public String getKpi() {
        return kpi;
    }

    public void setKpi(String kpi) {
        this.kpi = kpi;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", empId=" + empId +
                ", empname='" + empname + '\'' +
                ", skill='" + skill + '\'' +
                ", rating='" + rating + '\'' +
                ", experience='" + experience + '\'' +
                ", certification='" + certification + '\'' +
                ", kpi='" + kpi + '\'' +
                '}';
    }
}
