package com.assessment.backend.service.Impl;

import com.assessment.backend.Repository.EmployeeRepository;
import com.assessment.backend.model.Employee;
import com.assessment.backend.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EmployeeServiceImpl implements EmployeeService{
    @Autowired
    private EmployeeRepository employeeRepository;
    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }
    //Serviceimplementation class is used to implement the logic using interface methods
}
