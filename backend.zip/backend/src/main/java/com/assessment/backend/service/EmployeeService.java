package com.assessment.backend.service;

import com.assessment.backend.model.Employee;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface EmployeeService {
    //service interface is used to declare the  methods
    public List<Employee> getAllEmployees();
}
