package com.assessment.backend.exception;


//created to handle the errors & exceptions in creating database
public class ResourceNotFoundException extends RuntimeException{

    private static final long serialVersionUID = 1L;

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
